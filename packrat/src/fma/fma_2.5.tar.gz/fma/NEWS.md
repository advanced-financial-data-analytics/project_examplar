## Version 2.5
  * Reduced package dependencies

## Version 2.4
  * Added pkgdown
  * Added a vignette
  * Fixed start date in milk data set

## Version 2.3
  * Removed tseries dependency

## Version 2.2
  * Changed URL for book

## Version 2.01
	* NAMESPACE added and .First.lib removed.

## Version 2.00
  * Package removed from forecasting bundle

For details of earlier versions, please see the Changelog of the forecast package.
