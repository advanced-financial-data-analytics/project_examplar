## Causality tests
## Granger and instantaneous causality
var.causal <- causality(varsimest, cause = "y2")
