
# Placeholder with simple test
expect_equal(1 + 1, 2)

